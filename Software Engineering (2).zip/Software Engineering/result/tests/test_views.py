from rest_framework.test import APITestCase
from result.views import *
from rest_framework import status
from django.urls import reverse

class TestViews(APITestCase):
    def test_view_function(self):
        url = reverse('creates')
        data = {
            'name':'gkon',
            'roll':321,
            'section':'fs3'
               }
        response = self.client.post(path = url,data = data , format = 'json')
        self.assertEqual(response.json(),{'msg':'Data Save Successfully'})
        self.assertEqual(response.status_code,status.HTTP_200_OK)

