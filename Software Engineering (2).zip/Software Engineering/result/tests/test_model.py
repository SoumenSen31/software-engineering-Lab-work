from django.test import TestCase
from result.models import Student

class TestModelStudent(TestCase):
    def test_student_function(self):
        student = Student.objects.create(name = 'gkon',roll = 321, section = '8dm')
        self.assertEqual(student.name , 'gkon')
        self.assertEqual(student.roll, 321)
        self.assertEqual(student.section, '8dm')