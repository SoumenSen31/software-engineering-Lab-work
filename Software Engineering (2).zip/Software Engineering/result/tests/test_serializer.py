from rest_framework.test import APITestCase
from result.serializer import StudentSerializer

class SerializerTestClass(APITestCase):
    def test_student_serializer(self):
        data = {
            'name':'gkon',
            'roll':321,
            'section':'fs3'
        }
        serializer = StudentSerializer(data = data)
        self.assertTrue(serializer.is_valid())
        self.assertEqual(serializer.errors,{})